const functions = require('firebase-functions');
const admin = require('firebase-admin');
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors({ origin: true }));



var serviceAccount = require("./permissions.json");
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://project221-1772f.firebaseio.com"
});
const db = admin.firestore();

// create
app.post('/api/create', (req, res) => {
    (async () => {
        try {
            await db.collection('patients').doc('/' + req.body.id + '/').create({ firstName: req.body.firstName, lastName: req.body.lastName, pass: req.body.pass });
            return res.status(200).send();
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});

// read item
app.get('/api/read/:item_id', (req, res) => {
    (async () => {
        try {
            const document = db.collection('items').doc(req.params.item_id);
            let item = await document.get();
            let response = item.data();
            return res.status(200).send(response);
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});

// read all
app.get('/api/read', (req, res) => {
    (async () => {
        try {
            let query = db.collection('items');
            let response = [];
            await query.get().then(querySnapshot => {
                let docs = querySnapshot.docs;
                for (let doc of docs) {
                    const selectedItem = {
                        id: doc.id,
                        item: doc.data().item
                    };
                    response.push(selectedItem);
                }
                return response;
            });
            return res.status(200).send(response);
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});

// update
app.put('/api/update/:item_id', (req, res) => {
    (async () => {
        try {
            const document = db.collection('items').doc(req.params.item_id);
            await document.update({
                item: req.body.item
            });
            return res.status(200).send();
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});

// delete
app.delete('/api/delete/:item_id', (req, res) => {
    (async () => {
        try {
            const document = db.collection('items').doc(req.params.item_id);
            await document.delete();
            return res.status(200).send();
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }
    })();
});

//---------------------
app.post('/api/login', (req, res) => {



    (async () => {

        response = await login(req, res);

        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }
        else {
            return res.status(200).send(response);
        }

    })();
});

//a dcotro can get a full list of patients
//also, he has a flag that will show only his patients 
//this is for the case we will have more than one doctor

// read all
app.post('/api/getAllPatients', (req, res) => {
    (async () => {

        //first, login with doctor credentials
        //we always login again, because we are in stateless mode

        response = await login(req, res);
        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }

        if (response.ok === false) {
            return res.status(200).send(response);
        }

        console.log("login ok");

        response.data = await getAllPatients(req, res);

        console.log("data", response.data)

        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }


        return res.status(200).send(response);

    })();
});


app.post('/api/createPatient', (req, res) => {
    (async () => {

        response = {}

        //login with doctor
        response = await login(req, res);
        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }

        if (response.ok === false) {
            return res.status(200).send(response);
        }


// вынуть добавку личных данных врача из логина ?

        console.log("login ok");

        //try to insert new, it may crash with "already exist"

        try {
            await db.collection('patients').doc('/' + req.body.patientID + '/').create(
                {
                    patientPassword: req.body.patientPassword,
                    patientFirstName: req.body.patientFirstName,
                    patientLastName: req.body.patientLastName,
                    patientBirthDate: req.body.patientBirthDate,
                    patientGender: req.body.patientGender,
                    patientEmail: req.body.patientEmail,
                    patientPhone: req.body.patientPhone,
                    patientDoctorID: req.body.patientDoctorID,
                    diagnoses: [],
                    messages: []

                });
            response.ok = true;
            return res.status(200).send(response);
        } catch (error) {

            if (error.code == 6) { //means document already exists
                response.ok = false;
                response.err = "Document already exist"
                return res.status(200).send(response);
            }

            console.log(error);
            return res.status(500).send(error);
        }
    })();
});


app.post('/api/getPatient', (req, res) => {

    (async () => {
        response = {}

        //login with doctor
        response = await login(req, res);
        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }

        if (response.ok === false) {
            return res.status(200).send(response);
        }

        try {
            const document = db.collection('patients').doc(req.body.patientID);
            let item = await document.get();
            let response = item.data();
            response.ok = true;
            return res.status(200).send(response);
        } catch (error) {
            console.log(error);
            return res.status(500).send(error);
        }



    })();
});

app.post('/api/updatePatient', (req, res) => {
    (async () => {

        response = {}

        //login with doctor
        response = await login(req, res);
        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }

        if (response.ok === false) {
            return res.status(200).send(response);
        }


        try {
            const document = db.collection('patients').doc(req.body.patientID);
            await document.update({
                patientPassword: req.body.patientPassword,
                patientFirstName: req.body.patientFirstName,
                patientLastName: req.body.patientLastName,
                patientBirthDate: req.body.patientBirthDate,
                patientGender: req.body.patientGender,
                patientEmail: req.body.patientEmail,
                patientPhone: req.body.patientPhone,
                patientDoctorID: req.body.patientDoctorID
            });
            response.ok = true;
            return res.status(200).send(response);
        } catch (error) {
            console.log(error);
            response.ok = false;
            response.error = error;
            return res.status(500).send(response);
        }
    })();
});


app.post('/api/addMessage', (req, res) => {
    (async () => {

        response = {}

        //login with doctor
        response = await login(req, res);
        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }

        if (response.ok === false) {
            return res.status(200).send(response);
        }



        try {
            const document = db.collection('patients').doc(req.body.patientID);

            message = {}
            if (req.body.isDoctor){
                message.from = "Dr. "+response.data.firstName;
            }
            else{
                message.from = response.data.patientFirstName;
            }
            
            message.time = new Date(Date.now()).toLocaleString();
            message.text = req.body.message;

            await document.update({
                messages: admin.firestore.FieldValue.arrayUnion(message),
            });

            //reset the response
            response = {}

            response.ok = true;
            return res.status(200).send(response);
        } catch (error) {
            console.log(error);
            response.ok = false;
            response.error = error;
            return res.status(500).send(response);
        }
    })();
});


app.post('/api/addDiagnose', (req, res) => {
    (async () => {

        response = {}

        //login with doctor
        response = await login(req, res);
        if (typeof response.error !== 'undefined' && response.error) {
            return res.status(500).send(response);
        }

        if (response.ok === false) {
            return res.status(200).send(response);
        }


        try {
            const document = db.collection('patients').doc(req.body.patientID);

            diagnose = {}
           
            diagnose.time = new Date(Date.now()).toLocaleString();
            diagnose.diagnose = req.body.diagnose;

            await document.update({
                diagnoses: admin.firestore.FieldValue.arrayUnion(diagnose),
            });
            response.ok = true;
            return res.status(200).send(response);
        } catch (error) {
            console.log(error);
            response.ok = false;
            response.error = error;
            return res.status(500).send(response);
        }
    })();
});




//-----------------  functions  -----------------

async function login(req, resp) {

    var response = {};
    try {

        var collection = 'patients'
        if (typeof req.body.isDoctor !== 'undefined' && req.body.isDoctor) {
            collection = 'doctors'
        }


        if (typeof req.body.id !== 'undefined' && req.body.id && req.body.id !== "") {
            const document = db.collection(collection).doc(req.body.id);
            let item = await document.get()
            let data = item.data()
            if (typeof data !== 'undefined' && data) {
                //we got some data
                var pass = {}
                var firstName = {}
                if (typeof req.body.isDoctor !== 'undefined' && req.body.isDoctor){
                    pass = item.data().pass;
                }
                else{
                    pass = item.data().patientPassword;
                }
                if (pass == req.body.pass) {
                    response.ok = true
                    response.data = data;
                    return response;
                }
            }
        }

        response.ok = false
        response.err = "Wrong username/password"

    } catch (error) {
        response.ok = false
        response.err = "error in login func"
        response.error = error
    }

    return response;
}




async function getAllPatients(req, resp) {

    var response = {};

    try {
        let query = db.collection('patients');
        let response = [];

        queryResult = {}
        if (req.body.getAllPatients == false) {
            query = query.where('doctorID', '==', req.body.id);
        }

        await query.get().then(querySnapshot => {
            let docs = querySnapshot.docs;
            for (let doc of docs) {
                console.log("doc", doc);
                const selectedItem = {
                    id: doc.id,
                    firstName: doc.data().firstName,
                    lastName: doc.data().lastName
                };
                response.push(selectedItem);
            }
            return response;
        });
        return response;

    } catch (error) {
        console.log(error);
        response.error = error
    }

    return response;
}


exports.app = functions.https.onRequest(app);
